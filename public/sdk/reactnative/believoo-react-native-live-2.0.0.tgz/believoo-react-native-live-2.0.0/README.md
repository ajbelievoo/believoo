# @believoo/react-native-live

BelieVoo Live Streaming SDK for React Native

## Installation

```bash
npm install @believoo/react-native-live
# or
yarn add @believoo/react-native-live

# iOS
cd ios && pod install
```

## Usage

```javascript
import { initWithHost, useBelieVooLive, BelieVooLiveView } from "@believoo/react-native-live";

// Initialize
await initWithHost("wss://your-host.com");

// Using Hook
function StreamingScreen() {
  const { joinChannel, leaveChannel, isStreaming } = useBelieVooLive({
    appId: "bel_your_id",
    appCertificate: "your_cert"
  });

  return (
    <View>
      <BelieVooLiveView
        mode="broadcast"
        channel="my-channel"
        appId="bel_your_id"
        token="your_token"
        style={{ width: 300, height: 400 }}
      />
      <Button
        title={isStreaming ? "Stop" : "Start"}
        onPress={() => isStreaming ? leaveChannel() : joinChannel("channel", "token", 12345)}
      />
    </View>
  );
}
```

## Support

support@believoo.com
https://believoo.com/docs/streaming

App ID: bel_06ad61f458468c57b1d48a29

