import { NativeModules, requireNativeComponent, ViewProps } from "react-native";
import { useEffect, useRef, useState, useCallback } from "react";

const { BelieVooLiveModule } = NativeModules;
const BelieVooLiveViewNative = requireNativeComponent("BelieVooLiveView");

export interface LiveConfig {
  appId: string;
  appCertificate: string;
  host?: string;
}

export function initWithHost(host: string): Promise<void> {
  return BelieVooLiveModule.initWithHost(host);
}

export function joinBroadcastChannel(
  channel: string,
  token: string,
  uid: number
): Promise<void> {
  return BelieVooLiveModule.joinBroadcastChannel(channel, token, uid);
}

export function joinAudienceChannel(
  channel: string,
  token: string,
  uid: number
): Promise<void> {
  return BelieVooLiveModule.joinAudienceChannel(channel, token, uid);
}

export function leaveChannel(): Promise<void> {
  return BelieVooLiveModule.leaveChannel();
}

export function release(): Promise<void> {
  return BelieVooLiveModule.release();
}

export function useBelieVooLive(config: LiveConfig) {
  const [isStreaming, setIsStreaming] = useState(false);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    initWithHost(config.host || "wss://live.believoo.com");
    return () => {
      release();
    };
  }, []);

  const joinChannel = useCallback(async (channel: string, token: string, uid: number, role: "broadcaster" | "audience" = "broadcaster") => {
    if (role === "broadcaster") {
      await joinBroadcastChannel(channel, token, uid);
    } else {
      await joinAudienceChannel(channel, token, uid);
    }
    setIsStreaming(true);
    setIsConnected(true);
  }, []);

  const leave = useCallback(async () => {
    await leaveChannel();
    setIsStreaming(false);
    setIsConnected(false);
  }, []);

  return { joinChannel, leaveChannel: leave, isStreaming, isConnected };
}

export interface BelieVooLiveViewProps extends ViewProps {
  mode: "broadcast" | "audience";
  channel: string;
  appId: string;
  token: string;
}

export function BelieVooLiveView(props: BelieVooLiveViewProps) {
  return <BelieVooLiveViewNative {...props} />;
}
