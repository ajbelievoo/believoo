export function initWithHost(host: string): Promise<void>;
export function joinBroadcastChannel(channel: string, token: string, uid: number): Promise<void>;
export function joinAudienceChannel(channel: string, token: string, uid: number): Promise<void>;
export function leaveChannel(): Promise<void>;
export function release(): Promise<void>;

export interface LiveConfig {
  appId: string;
  appCertificate: string;
  host?: string;
}

export interface BelieVooLiveViewProps {
  mode: "broadcast" | "audience";
  channel: string;
  appId: string;
  token: string;
  style?: any;
}

export function useBelieVooLive(config: LiveConfig): {
  joinChannel: (channel: string, token: string, uid: number, role?: "broadcaster" | "audience") => Promise<void>;
  leaveChannel: () => Promise<void>;
  isStreaming: boolean;
  isConnected: boolean;
};

export function BelieVooLiveView(props: BelieVooLiveViewProps): JSX.Element;

