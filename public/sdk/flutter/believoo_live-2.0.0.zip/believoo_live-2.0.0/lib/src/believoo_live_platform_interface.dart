import "dart:async";
import "package:flutter/foundation.dart";
import "package:flutter/services.dart";

class BelieVooLivePlatformInterface {
  static const MethodChannel _channel = MethodChannel("believoo_live");

  static Future<void> initWithHost(String host) async {
    await _channel.invokeMethod("initWithHost", {"host": host});
  }

  static Future<void> joinBroadcastChannel(
    String channel,
    String token,
    int uid,
  ) async {
    await _channel.invokeMethod("joinBroadcastChannel", {
      "channel": channel,
      "token": token,
      "uid": uid,
    });
  }

  static Future<void> joinAudienceChannel(
    String channel,
    String token,
    int uid,
  ) async {
    await _channel.invokeMethod("joinAudienceChannel", {
      "channel": channel,
      "token": token,
      "uid": uid,
    });
  }

  static Future<void> leaveChannel() async {
    await _channel.invokeMethod("leaveChannel");
  }

  static Future<void> release() async {
    await _channel.invokeMethod("release");
  }
}
