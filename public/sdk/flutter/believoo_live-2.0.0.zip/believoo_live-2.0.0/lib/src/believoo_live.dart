import "dart:async";
import "believoo_live_platform_interface.dart";

export "package:flutter/material.dart";

class BelieVooLive {
  static String? _host;
  static bool _initialized = false;

  /// Initialize SDK with host
  static Future<void> initWithHost(String host) async {
    _host = host;
    _initialized = true;
    await BelieVooLivePlatformInterface.initWithHost(host);
    print("[BelieVoo] Flutter SDK v2.0.0 initialized");
  }

  /// Join as broadcaster
  static Future<void> joinBroadcastChannel(
    String channel,
    String token,
    int uid, {
    Function? onSuccess,
    Function(String)? onError,
  }) async {
    if (!_initialized) {
      throw Exception("BelieVoo not initialized. Call initWithHost() first.");
    }

    try {
      await BelieVooLivePlatformInterface.joinBroadcastChannel(
        channel,
        token,
        uid,
      );
      onSuccess?.call();
      print("[BelieVoo] Broadcasting to $channel as uid $uid");
    } catch (e) {
      onError?.call(e.toString());
    }
  }

  /// Join as audience
  static Future<void> joinAudienceChannel(
    String channel,
    String token,
    int uid, {
    Function? onSuccess,
    Function(String)? onError,
  }) async {
    if (!_initialized) {
      throw Exception("BelieVoo not initialized. Call initWithHost() first.");
    }

    try {
      await BelieVooLivePlatformInterface.joinAudienceChannel(
        channel,
        token,
        uid,
      );
      onSuccess?.call();
      print("[BelieVoo] Watching $channel as uid $uid");
    } catch (e) {
      onError?.call(e.toString());
    }
  }

  /// Leave channel
  static Future<void> leaveChannel() async {
    await BelieVooLivePlatformInterface.leaveChannel();
    print("[BelieVoo] Left channel");
  }

  /// Release resources
  static Future<void> release() async {
    await BelieVooLivePlatformInterface.release();
    _initialized = false;
    print("[BelieVoo] Released");
  }
}

/// BelieVoo Video View Widget
class BelieVooVideoView extends StatelessWidget {
  final int uid;
  final bool isLocal;
  final BoxFit fit;

  const BelieVooVideoView({
    Key? key,
    required this.uid,
    this.isLocal = false,
    this.fit = BoxFit.cover,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Center(
        child: Text(
          isLocal ? "Local Video (UID: $uid)" : "Remote Video (UID: $uid)",
          style: const TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}

