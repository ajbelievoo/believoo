import "dart:async";
import "dart:html" as html;
import "package:flutter/services.dart";
import "package:flutter_web_plugins/flutter_web_plugins.dart";

class BelieVooLiveWeb {
  static void registerWith(Registrar registrar) {
    final MethodChannel channel = MethodChannel(
      "believoo_live",
      const StandardMethodCodec(),
      registrar,
    );
    final instance = BelieVooLiveWeb();
    channel.setMethodCallHandler(instance.handleMethodCall);
  }

  Future<dynamic> handleMethodCall(MethodCall call) async {
    switch (call.method) {
      case "initWithHost":
        return _initWithHost(call.arguments["host"]);
      case "joinBroadcastChannel":
        return _joinBroadcast(call.arguments);
      case "joinAudienceChannel":
        return _joinAudience(call.arguments);
      case "leaveChannel":
        return _leaveChannel();
      case "release":
        return _release();
      default:
        throw MissingPluginException();
    }
  }

  void _initWithHost(String host) {
    print("[BelieVoo] Web SDK initialized with $host");
  }

  void _joinBroadcast(dynamic args) {
    final channel = args["channel"];
    final token = args["token"];
    print("[BelieVoo] Broadcasting to $channel");
  }

  void _joinAudience(dynamic args) {
    final channel = args["channel"];
    print("[BelieVoo] Watching $channel");
  }

  void _leaveChannel() {
    print("[BelieVoo] Left channel");
  }

  void _release() {
    print("[BelieVoo] Released");
  }
}
