# BelieVoo Live SDK for Flutter

## Installation

```yaml
dependencies:
  believoo_live: ^2.0.0
```

## Usage

```dart
import "package:believoo_live/believoo_live.dart";

void main() async {
  await BelieVooLive.initWithHost("https://your-host.com");
  
  // Broadcast
  await BelieVooLive.joinBroadcastChannel(
    "my-channel",
    "token",
    12345,
  );
  
  // Watch
  await BelieVooLive.joinAudienceChannel(
    "my-channel",
    "token",
    67890,
  );
}
```

## Support

support@believoo.com
https://believoo.com/docs/streaming

App ID: bel_06ad61f458468c57b1d48a29

