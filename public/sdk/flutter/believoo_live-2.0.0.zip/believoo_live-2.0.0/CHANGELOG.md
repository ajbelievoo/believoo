CHANGELOG

## 2.0.0

- Initial release
- Android and iOS support
- Web support (experimental)
- Broadcasting and audience modes
- WebRTC-based streaming


