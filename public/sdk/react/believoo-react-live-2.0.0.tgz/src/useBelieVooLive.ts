import { useEffect, useRef, useState, useCallback } from "react";
import { BelieVooClient } from "./BelieVooClient";
import { LiveConfig } from "./types";

export function useBelieVooLive(config: LiveConfig) {
  const clientRef = useRef<BelieVooClient | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    clientRef.current = new BelieVooClient(config);
    
    return () => {
      clientRef.current?.release();
    };
  }, [config.appId]);

  const joinChannel = useCallback(async (
    channel: string,
    token: string,
    uid: string,
    videoElement?: HTMLVideoElement,
    role: "broadcaster" | "audience" = "broadcaster"
  ) => {
    try {
      if (role === "broadcaster") {
        await clientRef.current?.joinBroadcastChannel(channel, token, uid, videoElement);
      } else {
        await clientRef.current?.joinAudienceChannel(channel, token, uid, videoElement);
      }
      setIsStreaming(true);
      setIsConnected(true);
    } catch (err) {
      setError(err as Error);
    }
  }, []);

  const leaveChannel = useCallback(() => {
    clientRef.current?.leaveChannel();
    setIsStreaming(false);
    setIsConnected(false);
  }, []);

  return {
    joinChannel,
    leaveChannel,
    isStreaming,
    isConnected,
    error
  };
}

