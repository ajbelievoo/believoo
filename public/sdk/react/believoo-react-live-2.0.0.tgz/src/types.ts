export interface LiveConfig {
  appId: string;
  appCertificate: string;
  host?: string;
  token?: string;
}

export interface StreamStats {
  bitrate: number;
  fps: number;
  latency: number;
}

export type StreamEvent = "joined" | "left" | "error" | "stats";

