import { LiveConfig, StreamStats, StreamEvent } from "./types";

export class BelieVooClient {
  private appId: string;
  private host: string;
  private ws: WebSocket | null = null;
  private pc: RTCPeerConnection | null = null;
  private localStream: MediaStream | null = null;
  private eventListeners: Map<StreamEvent, Function[]> = new Map();

  constructor(config: LiveConfig) {
    this.appId = config.appId;
    this.host = config.host || "wss://live.believoo.com";
    console.log("[BelieVoo] SDK v2.0.0 initialized");
  }

  async initWithHost(host: string): Promise<void> {
    this.host = host;
    console.log("[BelieVoo] Host configured:", host);
  }

  async joinBroadcastChannel(
    channel: string,
    token: string,
    uid: string,
    videoElement?: HTMLVideoElement
  ): Promise<void> {
    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });

      if (videoElement) {
        videoElement.srcObject = this.localStream;
      }

      this.pc = new RTCPeerConnection({
        iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
      });

      this.localStream.getTracks().forEach(track => {
        this.pc?.addTrack(track, this.localStream!);
      });

      this.ws = new WebSocket(`${this.host}/ws/${channel}?token=${token}&uid=${uid}&role=broadcaster`);
      
      this.ws.onopen = () => {
        console.log("[BelieVoo] Connected to", channel);
        this.emit("joined", { channel, uid });
      };

      this.setupPeerConnection();
      this.emit("joined", { channel, uid });
    } catch (err) {
      console.error("[BelieVoo] Error joining channel:", err);
      this.emit("error", err);
      throw err;
    }
  }

  async joinAudienceChannel(
    channel: string,
    token: string,
    uid: string,
    videoElement?: HTMLVideoElement
  ): Promise<void> {
    try {
      this.pc = new RTCPeerConnection({
        iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
      });

      this.pc.ontrack = (event) => {
        if (videoElement && event.streams[0]) {
          videoElement.srcObject = event.streams[0];
        }
      };

      this.ws = new WebSocket(`${this.host}/ws/${channel}?token=${token}&uid=${uid}&role=audience`);
      
      this.ws.onopen = () => {
        console.log("[BelieVoo] Watching", channel);
        this.emit("joined", { channel, uid });
      };

      this.setupPeerConnection();
    } catch (err) {
      console.error("[BelieVoo] Error:", err);
      this.emit("error", err);
    }
  }

  private setupPeerConnection(): void {
    if (!this.pc || !this.ws) return;

    this.pc.onicecandidate = (event) => {
      if (event.candidate) {
        this.ws?.send(JSON.stringify({
          type: "ice-candidate",
          candidate: event.candidate
        }));
      }
    };

    this.ws.onmessage = async (event) => {
      const message = JSON.parse(event.data);
      
      if (message.type === "offer") {
        await this.pc?.setRemoteDescription(new RTCSessionDescription(message.offer));
        const answer = await this.pc?.createAnswer();
        await this.pc?.setLocalDescription(answer);
        this.ws?.send(JSON.stringify({ type: "answer", answer }));
      }
      
      if (message.type === "ice-candidate") {
        await this.pc?.addIceCandidate(new RTCIceCandidate(message.candidate));
      }
    };
  }

  leaveChannel(): void {
    this.localStream?.getTracks().forEach(track => track.stop());
    this.pc?.close();
    this.ws?.close();
    this.emit("left", {});
    console.log("[BelieVoo] Left channel");
  }

  release(): void {
    this.leaveChannel();
    this.eventListeners.clear();
  }

  on(event: StreamEvent, callback: Function): void {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, []);
    }
    this.eventListeners.get(event)?.push(callback);
  }

  private emit(event: StreamEvent, data: any): void {
    this.eventListeners.get(event)?.forEach(cb => cb(data));
  }
}

